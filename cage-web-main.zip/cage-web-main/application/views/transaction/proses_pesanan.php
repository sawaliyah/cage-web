<div class="container-fluid">
    <div class="alert alert-success">
    <h3 class="text-center">Pesanan Anda Telah Berhasil Di Proses</h3>
    <h3 class="text-center">Silahkan Konfirmasi Pembayaran Anda Melalui Whatsapp</h3>
    </div>
    <center><a href="https://wa.me/6287883322595"><div class="btn btn-warning">Konfirmasi</div></a></center>
    <br>
</div>